import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Este widget configura la aplicación principal y el tema compartido.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //Este title se muestra en la barra de tareas y en el título de la aplicación.
      title: '2da APP Flutter',
      theme: ThemeData(
        // El esquema de color se reutiliza en ambas pantallas.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Página Home'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  // Esta línea indica que el estado de MyHomePage se maneja en _MyHomePageState.
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  // Incrementa el contador y redibuja la pantalla principal.
  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  // Navega hacia la segunda pantalla usando la pila de rutas de Flutter.
  void _goToSecondScreen() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) => const SecondScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Este método construye la interfaz de la pantalla principal.
    return Scaffold(
      // Scaffold aporta la estructura base con AppBar, body y botones flotantes.
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        // Center coloca el contenido en el medio de la pantalla.
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Has pulsado el botón:'),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Este botón conserva la funcionalidad original de incrementar el contador.
          FloatingActionButton(
            heroTag: 'incrementCounter',
            onPressed: _incrementCounter,
            tooltip: 'Increment',
            child: const Icon(Icons.add),
          ),
            // Este separador mantiene una distancia visual clara entre los botones.
            const SizedBox(height: 20),
          // Este botón abre la segunda pantalla y mantiene el formato circular.
          FloatingActionButton(
            heroTag: 'goToSecondScreen',
            onPressed: _goToSecondScreen,
            tooltip: 'Ir a la segunda pantalla',
            child: const Icon(Icons.arrow_forward),
          ),
        ],
      ),
    );
  }
}

class SecondScreen extends StatelessWidget {
  const SecondScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // El AppBar reutiliza el mismo color para mantener el formato visual.
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Volver',
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Segunda pantalla'),
      ),
      body: const Center(
        child: Text(
          '¡Hola, estamos en la segunda pantalla!',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
